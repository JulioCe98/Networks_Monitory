package Schema;

public class Declaraciones {
	
	private Object key = new Object();

	public synchronized void firstForm() {
		//a sincronizar
	}
	
	public void secondForm() {
		
		synchronized (key) {
			//a sincronizar
		}
		
	}
	
}
